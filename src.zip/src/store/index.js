import { createStore } from 'redux';
import { reducer } from './reducers';

const store = createStore(
    reducer,
    window.__REDUX_DEVTOOLS_EXETENSION__ && window.__REDUX_DEVTOOLS_EXETENSION__(),
    );
export default store;
store.dispatch(postsRequest());
fetch('http://localhost:9999/api/posts')
    .then(response => {
        if (!response.ok) {
            throw new Error('bad http status');
        }
        return response.json();
    })
    .then(body => {
        store.dispatch(postsSuccess(body));
    })
    .catch(error => {
        store.dispatch(postsFail(error));
    });