import React from 'react';
import Post from '../Post/Post';
import PostForm from '../PostForm/PostForm';
import { shallowEqual, useSelector } from 'react-redux';

function Wall() {
    const {items, loading, error} = useSelector(state => state.posts, shallowEqual);
    const dispatch = useDispatch();

    const handleReload = () => {
        dispatch(postsRequest());
    };
    if (loading) {
        return <>Идёт загрузка данных...</>;
    }
    if (error) {
        return <>Произошло ошибка. <button onClick={handleReload}>Повторить запрос?</button></>;
    }

    return (
        <>
            <PostForm />
            <div>
                {items.map(o => <Post key={o.id} post={o} />)}
            </div>
        </>
    );
}

export default Wall;


